import sys
sys.dont_write_bytecode = True
import atexit
import array
import base64
import datetime
import http.client
import http.server
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import secrets
import shutil
import socket
import ssl
import struct
import subprocess
import tarfile
import threading
import time
import urllib.parse
import urllib.request
import wave
import webbrowser

class Problem(Exception):
    pass

class Cancelled(Exception):
    pass

def stamp():
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")

def clean(value):
    return re.sub(r"https?://\S+", "[地址]", str(value))[:1200]

def clean_tail(value, limit=3200):
    text = re.sub(r"https?://\S+", "[地址]", str(value))
    return text[-limit:]

def sha256_file(path, cancel=None):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        while True:
            if cancel and cancel.is_set():
                raise Cancelled()
            chunk = source.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()

def read_tail(path, limit=4096):
    try:
        with Path(path).open("rb") as source:
            source.seek(0, os.SEEK_END)
            size = source.tell()
            source.seek(max(0, size - limit))
            return source.read().decode("utf-8", "replace")
    except (OSError, TypeError):
        return ""

def native_exec_probe(path, cancel=None):
    target = Path(path).resolve()
    source = None
    args = []
    for candidate, extra in (("/system/bin/true", []), ("/system/bin/toybox", ["true"]), ("/system/bin/sh", ["-c", "exit 0"])):
        if Path(candidate).is_file():
            source = Path(candidate)
            args = extra
            break
    if source is None:
        raise Problem("无法找到 Android 系统执行探针。")
    probe = target / (".a_exec_" + secrets.token_hex(8))
    proc = None
    try:
        try:
            shutil.copyfile(source, probe)
            os.chmod(probe, 0o700)
        except OSError as exc:
            raise Problem("这个文件夹不能准备本地 ARM64 执行探针：" + clean_tail(exc, 700))
        try:
            proc = subprocess.Popen([str(probe)] + args, cwd=str(target), stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        except (PermissionError, OSError) as exc:
            raise Problem("这个文件夹不能实际执行本地 ARM64 程序：" + clean_tail(exc, 700))
        deadline = time.monotonic() + 8
        while proc.poll() is None:
            if cancel and cancel.is_set():
                proc.terminate()
                try:
                    proc.wait(0.4)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()
                raise Cancelled()
            if time.monotonic() >= deadline:
                proc.terminate()
                try:
                    proc.wait(0.4)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()
                raise Problem("这个文件夹执行本地 ARM64 程序超时。")
            time.sleep(0.08)
        if proc.returncode != 0:
            detail = proc.stderr.read().decode("utf-8", "replace") if proc.stderr else "退出码 %s" % proc.returncode
            raise Problem("这个文件夹不能实际执行本地 ARM64 程序：" + clean_tail(detail, 1000))
    finally:
        if proc and proc.stderr:
            proc.stderr.close()
        probe.unlink(missing_ok=True)

def native_page_size():
    try:
        return int(os.sysconf("SC_PAGE_SIZE"))
    except Exception:
        return 4096

def elf_android_compatible(path, page_size):
    try:
        with Path(path).open("rb") as source:
            ident = source.read(16)
            if ident[:4] != b"\x7fELF":
                return True
            if len(ident) != 16 or ident[4] != 2 or ident[5] != 1:
                return False
            header = source.read(48)
            if len(header) != 48:
                return False
            fields = struct.unpack("<HHIQQQIHHHHHH", header)
            if fields[1] != 183:
                return False
            phoff, phentsize, phnum = fields[4], fields[8], fields[9]
            if phentsize < 56 or phnum < 1 or phnum > 4096:
                return False
            for index in range(phnum):
                source.seek(phoff + index * phentsize)
                raw = source.read(56)
                if len(raw) != 56:
                    return False
                item = struct.unpack("<IIQQQQQQ", raw)
                if item[0] == 1:
                    align = int(item[7])
                    if align < page_size or (int(item[3]) - int(item[2])) % page_size:
                        return False
        return True
    except (OSError, struct.error, ValueError):
        return False

def within(root, path):
    root = Path(root).resolve()
    path = Path(path).resolve()
    return path == root or root in path.parents

def mount_noexec(path):
    target = str(Path(path).resolve())
    best = ("", set())
    try:
        with open("/proc/mounts", "r", encoding="utf-8", errors="replace") as source:
            for line in source:
                parts = line.split()
                if len(parts) < 4:
                    continue
                mount = parts[1].replace("\\040", " ").replace("\\011", "\t")
                try:
                    mount = str(Path(mount).resolve())
                except OSError:
                    continue
                if target == mount or target.startswith(mount.rstrip("/") + "/"):
                    if len(mount) > len(best[0]):
                        best = (mount, set(parts[3].split(",")))
    except OSError:
        return False
    return "noexec" in best[1]

def directory_list(path="", offset=0):
    choices = []
    for candidate in (str(Path.home()), str(Path(__file__).resolve().parent), "/storage/emulated/0/Documents", "/storage/emulated/0", "/sdcard", os.getcwd()):
        try:
            value = str(Path(candidate).resolve(strict=True))
            if value not in choices and Path(value).is_dir():
                choices.append(value)
        except OSError:
            pass
    if not choices:
        raise Problem("没有可访问的文件夹。")
    target = Path(path or choices[0]).expanduser().resolve(strict=True)
    if not target.is_dir():
        raise Problem("这不是文件夹。")
    names = []
    try:
        with os.scandir(target) as entries:
            for entry in entries:
                try:
                    if entry.is_dir(follow_symlinks=False):
                        names.append(entry.name)
                except OSError:
                    pass
    except PermissionError:
        raise Problem("Pydroid 3 没有读取此文件夹的权限。")
    names.sort(key=str.casefold)
    offset = max(0, int(offset))
    return {"path": str(target), "parent": str(target.parent), "directories": [{"name": name, "path": str(target / name)} for name in names[offset:offset + 120]], "next": offset + 120 if offset + 120 < len(names) else None, "roots": choices, "writable": os.access(str(target), os.W_OK | os.X_OK)}

class Runtime:
    llm_model_url = "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/6dd44a1fb35d11b5d1b28902876ce3cc9e882d0e/qwen2.5-0.5b-instruct-q4_0.gguf?download=true"
    llm_model_sha256 = "7671c0c304e6ce5a7fc577bcb12aba01e2c155cc2efd29b2213c95b18edaf6ed"
    llama_url = "https://github.com/ggml-org/llama.cpp/releases/download/b10964/llama-b10964-bin-android-arm64.tar.gz"
    llama_sha256 = "f1e8466297dd3c9fbdc6dc5a92c10ebfffd3757981cb1db0d0a2099ef6c0ff99"
    sherpa_url = "https://github.com/k2-fsa/sherpa-onnx/releases/download/v1.13.8/sherpa-onnx-v1.13.8-android-aarch64-termux-static.tar.bz2"
    sherpa_sha256 = "e212d6c41a55b3d0ef0a7926796b4fa48d42ea173b759fafff60ced024dd0883"
    asr_model_url = "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17.tar.bz2"
    asr_model_sha256 = "7d1efa2138a65b0b488df37f8b89e3d91a60676e416f515b952358d83dfd347e"
    tts_model_url = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-melo-tts-zh_en.tar.bz2"
    tts_checksum_url = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/checksum.txt"
    tts_checksum_sha256 = "30d65b392bba8dfbdbc3479928d3f80adff2c71d4f518ce893d572b8aff021ee"
    manifest_schema = 3
    component_compat = {"llama": 3, "sherpa": 3, "asr": 3, "tts": 3, "llm": 3}

    def __init__(self, root):
        self.root = Path(root).resolve()
        self.home = self.root / ".a"
        self.downloads = self.home / "downloads"
        self.user_runtime = self.home / "runtime"
        self.models = self.home / "models"
        self.cache = self.home / "cache"
        self.env_home = self.home / "env"
        self.env_tmp = self.env_home / "tmp"
        self.env_config = self.env_home / "config"
        self.env_data = self.env_home / "data"
        self.env_state = self.env_home / "state"
        self.manifest = self.home / "manifest.json"
        for item in (self.home, self.downloads, self.models, self.cache, self.env_home, self.env_tmp, self.env_config, self.env_data, self.env_state):
            item.mkdir(mode=0o700, parents=True, exist_ok=True)
            if not within(self.root, item):
                raise Problem("运行目录越界。")
        self.runtime = self.choose_runtime_directory()
        self.runtime.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.native_external = not within(self.root, self.runtime)
        self.lock = threading.RLock()
        self.model_lock = threading.RLock()
        self.integrity_cache = {}
        self.server = None
        self.server_port = None
        self.server_model = "local"
        self.server_log = None
        self.cleanup_stale()

    def choose_runtime_directory(self):
        if not mount_noexec(self.root):
            try:
                native_exec_probe(self.root)
                return self.user_runtime
            except Problem:
                pass
        candidates = []
        raw_values = [Path(sys.executable), Path(sys.prefix), Path.home()]
        home_env = os.environ.get("HOME")
        if home_env:
            raw_values.append(Path(home_env))
        for raw in raw_values:
            try:
                resolved = raw.expanduser().resolve()
            except OSError:
                continue
            chain = [resolved] + list(resolved.parents)
            files_roots = [item for item in chain if item.name == "files" and str(item).startswith(("/data/user/", "/data/data/"))]
            private_roots = files_roots or [item for item in chain if str(item).startswith(("/data/user/", "/data/data/"))]
            for base in private_roots:
                if base not in candidates:
                    candidates.append(base)
        for base in candidates:
            target = base / ".a_native_runtime"
            try:
                target.mkdir(mode=0o700, parents=True, exist_ok=True)
                native_exec_probe(target)
                return target.resolve()
            except (OSError, Problem):
                continue
        raise Problem("所选文件夹不能执行本地 AI 运行时，而且无法使用 Pydroid 私有可执行目录。")

    def cleanup_stale(self):
        for item in list(self.cache.iterdir()):
            try:
                if item.is_dir():
                    shutil.rmtree(item, ignore_errors=True)
                else:
                    item.unlink(missing_ok=True)
            except OSError:
                pass
        for base, patterns in ((self.home, ("stage_*", "manifest_*.tmp", "memory_*.tmp")), (self.runtime, ("*_new_*",)), (self.models, ("*_new_*",))):
            for pattern in patterns:
                for item in base.glob(pattern):
                    try:
                        if item.is_dir():
                            shutil.rmtree(item, ignore_errors=True)
                        else:
                            item.unlink(missing_ok=True)
                    except OSError:
                        pass
        for item in self.downloads.iterdir():
            try:
                if item.is_file() and not item.name.endswith(".part"):
                    item.unlink(missing_ok=True)
            except OSError:
                pass

    def expected_source(self, name):
        return {
            "llama": (self.llama_url, self.llama_sha256),
            "sherpa": (self.sherpa_url, self.sherpa_sha256),
            "asr": (self.asr_model_url, self.asr_model_sha256),
            "tts": (self.tts_model_url, "checksum:" + self.tts_checksum_sha256),
            "llm": (self.llm_model_url, self.llm_model_sha256)
        }[name]

    def component_spec_hash(self, name):
        source, digest = self.expected_source(name)
        payload = json.dumps({"compat": self.component_compat[name], "source": source, "sha256": digest}, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(payload).hexdigest()

    def paths(self):
        llama_dir = self.runtime / "llama"
        sherpa_dir = self.runtime / "sherpa"
        asr_dir = self.models / "asr"
        tts_dir = self.models / "tts"
        return {
            "llama": llama_dir / "llama-server",
            "llama_dir": llama_dir,
            "sherpa_asr": sherpa_dir / "sherpa-onnx-offline",
            "sherpa_tts": sherpa_dir / "sherpa-onnx-offline-tts",
            "llm": self.models / "qwen2.5-0.5b-instruct-q4_0.gguf",
            "asr_model": asr_dir / "model.int8.onnx",
            "asr_tokens": asr_dir / "tokens.txt",
            "tts_model": tts_dir / "model.onnx",
            "tts_lexicon": tts_dir / "lexicon.txt",
            "tts_tokens": tts_dir / "tokens.txt",
            "tts_phone": tts_dir / "phone.fst",
            "tts_date": tts_dir / "date.fst",
            "tts_number": tts_dir / "number.fst"
        }

    def component_files(self, name):
        p = self.paths()
        return {
            "llama": [p["llama"]],
            "sherpa": [p["sherpa_asr"], p["sherpa_tts"]],
            "asr": [p["asr_model"], p["asr_tokens"]],
            "tts": [p["tts_model"], p["tts_lexicon"], p["tts_tokens"], p["tts_phone"], p["tts_date"], p["tts_number"]],
            "llm": [p["llm"]]
        }[name]

    def integrity_files(self, name):
        if name == "llama":
            directory = self.paths()["llama_dir"]
            if directory.is_dir():
                return sorted((item for item in directory.iterdir() if item.is_file()), key=lambda item: item.name)
        return self.component_files(name)

    def file_key(self, path):
        path = Path(path).resolve()
        if within(self.runtime, path):
            return "runtime:" + str(path.relative_to(self.runtime))
        if within(self.home, path):
            return "home:" + str(path.relative_to(self.home))
        raise Problem("组件文件路径越界。")

    def path_for_key(self, key):
        if key.startswith("runtime:"):
            target = (self.runtime / key[8:]).resolve()
            if within(self.runtime, target):
                return target
        if key.startswith("home:"):
            target = (self.home / key[5:]).resolve()
            if within(self.home, target):
                return target
        raise Problem("组件清单路径无效。")

    def load_manifest(self):
        try:
            value = json.loads(self.manifest.read_text("utf-8"))
            if isinstance(value, dict) and value.get("schema") == self.manifest_schema and isinstance(value.get("components"), dict):
                return value
        except Exception:
            pass
        return {"schema": self.manifest_schema, "components": {}}

    def files_valid(self, name):
        files = self.component_files(name)
        if not all(item.is_file() and item.stat().st_size > 0 for item in files):
            return False
        if name == "llm":
            try:
                with files[0].open("rb") as source:
                    return source.read(4) == b"GGUF" and files[0].stat().st_size > 300 * 1024 * 1024
            except OSError:
                return False
        return True

    def component_ok(self, name, cancel=None, verify_hashes=True):
        if not self.files_valid(name):
            return False
        data = self.load_manifest()
        entry = data.get("components", {}).get(name)
        if not isinstance(entry, dict) or entry.get("compat") != self.component_compat[name]:
            return False
        if not secrets.compare_digest(str(entry.get("spec_hash", "")), self.component_spec_hash(name)):
            return False
        recorded = entry.get("files")
        if not isinstance(recorded, dict) or not recorded:
            return False
        required = {self.file_key(item) for item in self.component_files(name)}
        if not required.issubset(recorded.keys()):
            return False
        signature = []
        paths = []
        try:
            for key in sorted(recorded):
                meta = recorded[key]
                if not isinstance(meta, dict):
                    return False
                target = self.path_for_key(key)
                if not target.is_file():
                    return False
                size = target.stat().st_size
                expected_size = int(meta.get("size", -1))
                expected_hash = str(meta.get("sha256", "")).lower()
                if size != expected_size or not re.fullmatch(r"[0-9a-f]{64}", expected_hash):
                    return False
                stat = target.stat()
                signature.append((key, size, stat.st_mtime_ns, expected_hash))
                paths.append((target, expected_hash))
        except (OSError, ValueError, Problem):
            return False
        signature = (self.component_spec_hash(name), tuple(signature))
        if verify_hashes and self.integrity_cache.get(name) == signature:
            return True
        if verify_hashes:
            for target, expected_hash in paths:
                self.check_cancel(cancel)
                try:
                    actual = sha256_file(target, cancel)
                except OSError:
                    return False
                if not secrets.compare_digest(actual.lower(), expected_hash):
                    return False
            self.integrity_cache[name] = signature
        return True

    def record_component(self, name, source, source_sha256="", cancel=None, trusted_hashes=None):
        data = self.load_manifest()
        files = {}
        trusted_hashes = trusted_hashes or {}
        for item in self.integrity_files(name):
            self.check_cancel(cancel)
            if not item.is_file():
                continue
            digest = trusted_hashes.get(item)
            if not digest:
                digest = sha256_file(item, cancel)
            files[self.file_key(item)] = {"size": item.stat().st_size, "sha256": str(digest).lower()}
        required = {self.file_key(item) for item in self.component_files(name)}
        if not required.issubset(files.keys()):
            raise Problem("组件安装后文件不完整。")
        source_text = str(source)
        match = re.search(r"/(?:download|resolve)/([^/]+)/", source_text)
        version = match.group(1) if match else source_text
        data["schema"] = self.manifest_schema
        data["updated"] = stamp()
        data.setdefault("components", {})[name] = {"compat": self.component_compat[name], "spec_hash": self.component_spec_hash(name), "version": version, "source": source_text, "source_sha256": str(source_sha256), "files": files}
        temporary = self.home / ("manifest_" + secrets.token_hex(5) + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as target:
            json.dump(data, target, ensure_ascii=False, separators=(",", ":"))
            target.flush()
            os.fsync(target.fileno())
        self.check_cancel(cancel)
        os.replace(temporary, self.manifest)
        signature = []
        for key in sorted(files):
            target = self.path_for_key(key)
            stat = target.stat()
            signature.append((key, stat.st_size, stat.st_mtime_ns, files[key]["sha256"]))
        self.integrity_cache[name] = (self.component_spec_hash(name), tuple(signature))

    def ready(self, cancel=None, verify_hashes=True):
        return all(self.component_ok(name, cancel, verify_hashes) for name in self.component_compat)

    def status(self):
        return "本地模型已就绪，可断网运行。" if self.ready(verify_hashes=False) else "首次开始时会自动下载本地模型；若所选位置不能执行原生程序，仅原生运行时会放到 Pydroid 私有目录。"



    def report(self, callback, text):
        if callback:
            callback(text)

    def check_cancel(self, cancel):
        if cancel and cancel.is_set():
            raise Cancelled()

    def subprocess_env(self, cwd=None, library_path=None):
        env = dict(os.environ)
        env["HOME"] = str(self.env_home)
        env["TMPDIR"] = str(self.env_tmp)
        env["TMP"] = str(self.env_tmp)
        env["TEMP"] = str(self.env_tmp)
        env["XDG_CACHE_HOME"] = str(self.cache)
        env["XDG_CONFIG_HOME"] = str(self.env_config)
        env["XDG_DATA_HOME"] = str(self.env_data)
        env["XDG_STATE_HOME"] = str(self.env_state)
        env["XDG_RUNTIME_DIR"] = str(self.env_tmp)
        if cwd:
            env["PWD"] = str(Path(cwd).resolve())
        if library_path:
            env["LD_LIBRARY_PATH"] = str(library_path) + ((":" + env["LD_LIBRARY_PATH"]) if env.get("LD_LIBRARY_PATH") else "")
        return env

    def download(self, url, destination, callback, label, cancel, minimum=1, expected_sha256=""):
        destination = Path(destination)
        destination.parent.mkdir(parents=True, exist_ok=True)
        part = destination.with_name(destination.name + ".part")
        existing = part.stat().st_size if part.exists() else 0
        headers = {"User-Agent": "a-offline-voice/2", "Accept-Encoding": "identity"}
        if existing:
            headers["Range"] = "bytes=%s-" % existing
        request = urllib.request.Request(url, headers=headers)
        try:
            response = urllib.request.urlopen(request, timeout=60, context=ssl.create_default_context())
        except Exception:
            if existing:
                part.unlink(missing_ok=True)
                request = urllib.request.Request(url, headers={"User-Agent": "a-offline-voice/2", "Accept-Encoding": "identity"})
                response = urllib.request.urlopen(request, timeout=60, context=ssl.create_default_context())
                existing = 0
            else:
                raise
        with response:
            code = getattr(response, "status", 200)
            mode = "ab" if existing and code == 206 else "wb"
            if mode == "wb":
                existing = 0
            try:
                total = int(response.headers.get("Content-Length", "0")) + existing
            except ValueError:
                total = 0
            done = existing
            last = 0.0
            with part.open(mode) as target:
                while True:
                    self.check_cancel(cancel)
                    chunk = response.read(1024 * 1024)
                    if not chunk:
                        break
                    target.write(chunk)
                    done += len(chunk)
                    now = time.monotonic()
                    if now - last >= 0.8:
                        if total:
                            self.report(callback, "%s %.1f / %.1f MB" % (label, done / 1048576, total / 1048576))
                        else:
                            self.report(callback, "%s %.1f MB" % (label, done / 1048576))
                        last = now
                target.flush()
                os.fsync(target.fileno())
        if part.stat().st_size < minimum:
            part.unlink(missing_ok=True)
            raise Problem(label + "下载不完整。")
        if expected_sha256:
            self.report(callback, label + "正在校验 SHA-256…")
            actual = sha256_file(part, cancel)
            if not secrets.compare_digest(actual.lower(), expected_sha256.lower()):
                part.unlink(missing_ok=True)
                raise Problem(label + "SHA-256 校验失败。")
        os.replace(part, destination)
        self.report(callback, label + "完成。")
    def extract(self, archive, destination):
        destination = Path(destination)
        destination.mkdir(parents=True, exist_ok=True)
        base = destination.resolve()
        with tarfile.open(archive, "r:*") as source:
            for member in source.getmembers():
                name = member.name.replace("\\", "/")
                if name.startswith("/") or ".." in Path(name).parts:
                    raise Problem("下载包包含越界路径。")
                target = (destination / name).resolve()
                if not within(base, target):
                    raise Problem("下载包包含越界路径。")
                if member.isdir():
                    target.mkdir(parents=True, exist_ok=True)
                elif member.isfile():
                    target.parent.mkdir(parents=True, exist_ok=True)
                    stream = source.extractfile(member)
                    if stream is None:
                        continue
                    with target.open("wb") as output:
                        shutil.copyfileobj(stream, output, 1024 * 1024)
                    try:
                        os.chmod(target, member.mode & 0o777)
                    except OSError:
                        pass

    def stage(self, name):
        path = self.home / ("stage_" + name + "_" + secrets.token_hex(6))
        path.mkdir(mode=0o700)
        return path

    def check_native_files(self, directory, cancel=None):
        page = native_page_size()
        if page not in (4096, 16384):
            raise Problem("当前 Android page size 为 %s 字节，未通过本程序兼容性验证。" % page)
        candidates = []
        for item in Path(directory).rglob("*"):
            self.check_cancel(cancel)
            if item.is_file() and (os.access(item, os.X_OK) or ".so" in item.name):
                candidates.append(item)
        for item in candidates:
            self.check_cancel(cancel)
            if not elf_android_compatible(item, page):
                raise Problem("原生运行库与当前 %s KB page size/ARM64 ELF 不兼容：%s" % (page // 1024, item.name))

    def probe_program(self, program, cwd, library_path=None, cancel=None):
        log = self.cache / ("probe_" + secrets.token_hex(6) + ".log")
        proc = None
        try:
            with log.open("wb") as target:
                try:
                    proc = subprocess.Popen([str(program), "--help"], cwd=str(cwd), env=self.subprocess_env(cwd, library_path), stdout=target, stderr=subprocess.STDOUT)
                except (PermissionError, OSError) as exc:
                    raise Problem("原生运行时无法执行：" + clean_tail(exc, 1200))
                deadline = time.monotonic() + 20
                while proc.poll() is None:
                    if cancel and cancel.is_set():
                        proc.terminate()
                        try:
                            proc.wait(0.4)
                        except subprocess.TimeoutExpired:
                            proc.kill()
                            proc.wait()
                        raise Cancelled()
                    if time.monotonic() >= deadline:
                        proc.terminate()
                        try:
                            proc.wait(0.4)
                        except subprocess.TimeoutExpired:
                            proc.kill()
                            proc.wait()
                        break
                    time.sleep(0.08)
                code = proc.returncode if proc.returncode is not None else 0
            if code not in (0, 1, -15, -9):
                raise Problem("原生运行时执行探测失败：" + clean_tail(read_tail(log), 2200))
            detail = read_tail(log).lower()
            if any(marker in detail for marker in ("cannot locate", "linker:", "dlopen failed", "exec format", "cannot open shared object")):
                raise Problem("原生运行时动态链接失败：" + clean_tail(read_tail(log), 2200))
        finally:
            if proc and proc.poll() is None:
                proc.kill()
                proc.wait()
            log.unlink(missing_ok=True)

    def install_llama(self, callback, cancel):
        final = self.runtime / "llama"
        if self.component_ok("llama", cancel):
            return
        archive = self.downloads / "llama.tar.gz"
        self.download(self.llama_url, archive, callback, "下载本地对话运行时", cancel, 10 * 1024 * 1024, self.llama_sha256)
        stage = self.stage("llama")
        try:
            self.report(callback, "解压本地对话运行时…")
            self.extract(archive, stage)
            servers = list(stage.rglob("llama-server"))
            if not servers:
                raise Problem("本地对话运行时中没有 llama-server。")
            final_tmp = self.runtime / ("llama_new_" + secrets.token_hex(4))
            final_tmp.mkdir(mode=0o700)
            shutil.copy2(servers[0], final_tmp / "llama-server")
            for source in stage.rglob("*.so"):
                target = final_tmp / source.name
                if not target.exists() or source.stat().st_size > target.stat().st_size:
                    shutil.copy2(source, target)
            for item in final_tmp.iterdir():
                try:
                    os.chmod(item, 0o700 if item.name == "llama-server" else 0o600)
                except OSError:
                    pass
            self.check_native_files(final_tmp, cancel)
            self.probe_program(final_tmp / "llama-server", final_tmp, final_tmp, cancel)
            shutil.rmtree(final, ignore_errors=True)
            os.replace(final_tmp, final)
            self.record_component("llama", self.llama_url, self.llama_sha256, cancel)
        finally:
            shutil.rmtree(stage, ignore_errors=True)
            archive.unlink(missing_ok=True)
    def install_sherpa(self, callback, cancel):
        final = self.runtime / "sherpa"
        if self.component_ok("sherpa", cancel):
            return
        machine = platform.machine().lower()
        if machine not in ("aarch64", "arm64"):
            raise Problem("当前设备不是 64 位 ARM Android，无法使用本地语音运行时。")
        archive = self.downloads / "sherpa.tar.bz2"
        self.download(self.sherpa_url, archive, callback, "下载离线语音运行时", cancel, 20 * 1024 * 1024, self.sherpa_sha256)
        stage = self.stage("sherpa")
        try:
            self.report(callback, "解压离线语音运行时…")
            self.extract(archive, stage)
            final_tmp = self.runtime / ("sherpa_new_" + secrets.token_hex(4))
            final_tmp.mkdir(mode=0o700)
            for name in ("sherpa-onnx-offline", "sherpa-onnx-offline-tts"):
                matches = [q for q in stage.rglob(name) if q.is_file()]
                if not matches:
                    raise Problem("离线语音运行时缺少 " + name + "。")
                shutil.copy2(matches[0], final_tmp / name)
                os.chmod(final_tmp / name, 0o700)
            self.check_native_files(final_tmp, cancel)
            self.probe_program(final_tmp / "sherpa-onnx-offline", final_tmp, cancel=cancel)
            self.probe_program(final_tmp / "sherpa-onnx-offline-tts", final_tmp, cancel=cancel)
            shutil.rmtree(final, ignore_errors=True)
            os.replace(final_tmp, final)
            self.record_component("sherpa", self.sherpa_url, self.sherpa_sha256, cancel)
        finally:
            shutil.rmtree(stage, ignore_errors=True)
            archive.unlink(missing_ok=True)
    def install_asr(self, callback, cancel):
        final = self.models / "asr"
        if self.component_ok("asr", cancel):
            return
        archive = self.downloads / "asr.tar.bz2"
        self.download(self.asr_model_url, archive, callback, "下载离线语音识别模型", cancel, 100 * 1024 * 1024, self.asr_model_sha256)
        stage = self.stage("asr")
        try:
            self.report(callback, "解压离线语音识别模型…")
            self.extract(archive, stage)
            model = next(iter(stage.rglob("model.int8.onnx")), None)
            tokens = next(iter(stage.rglob("tokens.txt")), None)
            if not model or not tokens:
                raise Problem("离线语音识别模型文件不完整。")
            final_tmp = self.models / ("asr_new_" + secrets.token_hex(4))
            final_tmp.mkdir(mode=0o700)
            shutil.copy2(model, final_tmp / "model.int8.onnx")
            shutil.copy2(tokens, final_tmp / "tokens.txt")
            shutil.rmtree(final, ignore_errors=True)
            os.replace(final_tmp, final)
            self.record_component("asr", self.asr_model_url, self.asr_model_sha256, cancel)
        finally:
            shutil.rmtree(stage, ignore_errors=True)
            archive.unlink(missing_ok=True)
    def install_tts(self, callback, cancel):
        final = self.models / "tts"
        if self.component_ok("tts", cancel):
            return
        checksum = self.downloads / "tts-checksum.txt"
        archive = self.downloads / "tts.tar.bz2"
        self.download(self.tts_checksum_url, checksum, callback, "下载语音合成模型校验表", cancel, 1000, self.tts_checksum_sha256)
        expected = ""
        try:
            for line in checksum.read_text("utf-8", errors="replace").splitlines():
                if "vits-melo-tts-zh_en.tar.bz2" in line:
                    match = re.search(r"(?i)\b([0-9a-f]{64})\b", line)
                    if match:
                        expected = match.group(1).lower()
                        break
            if not expected:
                raise Problem("语音合成模型校验表中缺少固定模型的 SHA-256。")
            self.download(self.tts_model_url, archive, callback, "下载离线语音合成模型", cancel, 20 * 1024 * 1024, expected)
            stage = self.stage("tts")
            try:
                self.report(callback, "解压离线语音合成模型…")
                self.extract(archive, stage)
                names = ("model.onnx", "lexicon.txt", "tokens.txt", "phone.fst", "date.fst", "number.fst")
                found = {name: next(iter(stage.rglob(name)), None) for name in names}
                if not all(found[name] for name in names):
                    raise Problem("离线语音合成模型文件不完整。")
                final_tmp = self.models / ("tts_new_" + secrets.token_hex(4))
                final_tmp.mkdir(mode=0o700)
                for name, source in found.items():
                    shutil.copy2(source, final_tmp / name)
                shutil.rmtree(final, ignore_errors=True)
                os.replace(final_tmp, final)
                self.record_component("tts", self.tts_model_url, expected, cancel)
            finally:
                shutil.rmtree(stage, ignore_errors=True)
        finally:
            archive.unlink(missing_ok=True)
            checksum.unlink(missing_ok=True)
    def install_llm(self, callback, cancel):
        final = self.paths()["llm"]
        if self.component_ok("llm", cancel):
            return
        self.download(self.llm_model_url, final, callback, "下载本地对话模型", cancel, 300 * 1024 * 1024, self.llm_model_sha256)
        with final.open("rb") as source:
            if source.read(4) != b"GGUF":
                final.unlink(missing_ok=True)
                raise Problem("本地对话模型格式无效。")
        self.record_component("llm", self.llm_model_url, self.llm_model_sha256, cancel, {final: self.llm_model_sha256})
    def ensure(self, callback=None, cancel=None):
        with self.lock:
            if platform.machine().lower() not in ("aarch64", "arm64"):
                raise Problem("当前设备不是 64 位 ARM Android，无法使用固定的本地运行时。")
            if self.ready(cancel):
                self.report(callback, "正在验证离线原生运行时兼容性…")
                native_exec_probe(self.runtime, cancel)
                page = native_page_size()
                if page not in (4096, 16384):
                    raise Problem("当前 Android page size 为 %s 字节，未通过本程序兼容性验证。" % page)
                p = self.paths()
                self.check_native_files(p["sherpa_asr"].parent, cancel)
                self.check_native_files(p["llama_dir"], cancel)
                self.probe_program(p["sherpa_asr"], p["sherpa_asr"].parent, cancel=cancel)
                self.probe_program(p["sherpa_tts"], p["sherpa_tts"].parent, cancel=cancel)
                self.probe_program(p["llama"], p["llama_dir"], p["llama_dir"], cancel)
                self.report(callback, "本地模型已就绪，可断网运行。")
                return
            if self.native_external:
                self.report(callback, "所选文件夹不能执行原生程序，仅把原生运行时放到 Pydroid 私有目录；模型、记忆和对话仍保存在所选文件夹。")
            self.report(callback, "正在验证 Android 原生运行时目录…")
            native_exec_probe(self.runtime, cancel)
            page = native_page_size()
            if page not in (4096, 16384):
                raise Problem("当前 Android page size 为 %s 字节，未通过本程序兼容性验证。" % page)
            free = shutil.disk_usage(self.root).free
            if free < 1500 * 1024 * 1024:
                raise Problem("所选文件夹剩余空间不足，首次准备本地模型需要至少约 1.5 GB 可用空间。")
            if self.native_external and shutil.disk_usage(self.runtime).free < 256 * 1024 * 1024:
                raise Problem("Pydroid 私有目录剩余空间不足，无法放置原生运行时。")
            self.install_sherpa(callback, cancel)
            self.check_cancel(cancel)
            self.install_llama(callback, cancel)
            self.check_cancel(cancel)
            self.report(callback, "原生运行时已通过 %s KB page size 与实际执行检查。" % (page // 1024))
            self.install_asr(callback, cancel)
            self.check_cancel(cancel)
            self.install_tts(callback, cancel)
            self.check_cancel(cancel)
            self.install_llm(callback, cancel)
            if not self.ready(cancel):
                raise Problem("本地模型准备未完成。")
            self.report(callback, "本地模型已就绪，可断网运行。")
    def process(self, args, timeout=180, cancel=None, cwd=None):
        self.check_cancel(cancel)
        cwd = Path(cwd or self.home).resolve()
        out_path = self.cache / ("proc_" + secrets.token_hex(8) + ".out")
        err_path = self.cache / ("proc_" + secrets.token_hex(8) + ".err")
        proc = None
        try:
            with out_path.open("wb") as output, err_path.open("wb") as error:
                try:
                    proc = subprocess.Popen([str(x) for x in args], cwd=str(cwd), env=self.subprocess_env(cwd), stdout=output, stderr=error)
                except (PermissionError, OSError) as exc:
                    raise Problem("本地原生运行时无法启动：" + clean_tail(exc, 1600))
                started = time.monotonic()
                while proc.poll() is None:
                    if cancel and cancel.is_set():
                        proc.terminate()
                        try:
                            proc.wait(0.5)
                        except subprocess.TimeoutExpired:
                            proc.kill()
                            proc.wait()
                        raise Cancelled()
                    if time.monotonic() - started > timeout:
                        proc.terminate()
                        try:
                            proc.wait(0.5)
                        except subprocess.TimeoutExpired:
                            proc.kill()
                            proc.wait()
                        raise Problem("本地模型处理超时。")
                    time.sleep(0.08)
            output_text = out_path.read_bytes().decode("utf-8", "replace")
            if proc.returncode != 0:
                detail = read_tail(err_path, 4096) or read_tail(out_path, 4096)
                raise Problem("本地模型运行失败：" + clean_tail(detail, 3200))
            return output_text
        finally:
            out_path.unlink(missing_ok=True)
            err_path.unlink(missing_ok=True)
    def transcribe(self, wav_path, cancel=None):
        p = self.paths()
        command = [p["sherpa_asr"], "--tokens=" + str(p["asr_tokens"]), "--sense-voice-model=" + str(p["asr_model"]), "--num-threads=" + str(max(1, min(4, os.cpu_count() or 2))), "--sense-voice-language=auto", "--sense-voice-use-itn=1", "--debug=0", wav_path]
        output = self.process(command, timeout=120, cancel=cancel, cwd=p["sherpa_asr"].parent)
        result = ""
        for line in output.splitlines():
            line = line.strip()
            if line.startswith("{") and '"text"' in line:
                try:
                    value = json.loads(line)
                    if isinstance(value, dict) and isinstance(value.get("text"), str):
                        result = value["text"].strip()
                except ValueError:
                    pass
        return result

    def tts(self, text, output, cancel=None):
        p = self.paths()
        command = [p["sherpa_tts"], "--vits-model=" + str(p["tts_model"]), "--vits-lexicon=" + str(p["tts_lexicon"]), "--vits-tokens=" + str(p["tts_tokens"]), "--sid=0", "--num-threads=" + str(max(1, min(4, os.cpu_count() or 2))), "--output-filename=" + str(output)]
        fsts = [str(p[name]) for name in ("tts_phone", "tts_date", "tts_number") if p[name].is_file()]
        if fsts:
            command.append("--tts-rule-fsts=" + ",".join(fsts))
        command.append(text[:1800])
        self.process(command, timeout=180, cancel=cancel, cwd=p["sherpa_tts"].parent)
        if not Path(output).is_file() or Path(output).stat().st_size < 44:
            raise Problem("离线语音合成没有生成有效音频。")

    def free_port(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
        sock.close()
        return port

    def server_alive(self):
        proc = self.server
        port = self.server_port
        if not proc or proc.poll() is not None or not port:
            return False
        try:
            conn = http.client.HTTPConnection("127.0.0.1", port, timeout=2)
            conn.request("GET", "/health")
            response = conn.getresponse()
            response.read()
            conn.close()
            return response.status < 500
        except Exception:
            return False

    def start_server(self, cancel=None):
        self.check_cancel(cancel)
        with self.lock:
            if self.server_alive():
                return
            self.stop_server()
            self.check_cancel(cancel)
            p = self.paths()
            port = self.free_port()
            command = [str(p["llama"]), "--model", str(p["llm"]), "--ctx-size", "4096", "--threads", str(max(1, min(4, os.cpu_count() or 2))), "--host", "127.0.0.1", "--port", str(port), "--parallel", "1", "--alias", self.server_model]
            env = self.subprocess_env(p["llama_dir"], p["llama_dir"])
            log_path = self.cache / ("llama_server_" + secrets.token_hex(6) + ".log")
            try:
                with log_path.open("wb") as log:
                    self.server = subprocess.Popen(command, cwd=str(p["llama_dir"]), env=env, stdout=log, stderr=subprocess.STDOUT)
            except (PermissionError, OSError) as exc:
                self.server = None
                log_path.unlink(missing_ok=True)
                raise Problem("本地对话模型无法启动：" + clean_tail(exc, 1800))
            self.server_log = log_path
            self.server_port = port
        deadline = time.monotonic() + 120
        while time.monotonic() < deadline:
            if cancel and cancel.is_set():
                self.stop_server(0.25)
                raise Cancelled()
            if not self.server or self.server.poll() is not None:
                detail = clean_tail(read_tail(self.server_log, 4096), 3200)
                self.stop_server(0.25)
                raise Problem("本地对话模型启动失败：" + (detail or "没有启动日志。"))
            if self.server_alive():
                return
            time.sleep(0.25)
        detail = clean_tail(read_tail(self.server_log, 4096), 3200)
        self.stop_server()
        raise Problem("本地对话模型启动超时：" + (detail or "没有启动日志。"))
    def stop_server(self, grace=2.0):
        with self.lock:
            proc = self.server
            log_path = self.server_log
            self.server = None
            self.server_port = None
            self.server_log = None
        if proc and proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(grace)
            except subprocess.TimeoutExpired:
                proc.kill()
                try:
                    proc.wait(1)
                except subprocess.TimeoutExpired:
                    pass
        if log_path:
            Path(log_path).unlink(missing_ok=True)
    def interrupt_model(self):
        self.stop_server(0.25)

    def chat(self, messages, max_tokens=320, cancel=None):
        acquired = False
        while not acquired:
            self.check_cancel(cancel)
            acquired = self.model_lock.acquire(timeout=0.1)
        conn = None
        done = threading.Event()
        try:
            self.check_cancel(cancel)
            self.start_server(cancel)
            payload = json.dumps({"model": self.server_model, "messages": messages, "max_tokens": max_tokens, "temperature": 0.65, "stream": False}, ensure_ascii=False).encode("utf-8")
            if cancel:
                def watch_cancel():
                    while not done.wait(0.08):
                        if cancel.is_set():
                            self.interrupt_model()
                            return
                threading.Thread(target=watch_cancel, name="model-cancel", daemon=True).start()
            try:
                conn = http.client.HTTPConnection("127.0.0.1", self.server_port, timeout=240)
                conn.request("POST", "/v1/chat/completions", body=payload, headers={"Content-Type": "application/json"})
                response = conn.getresponse()
                data = response.read(4 * 1024 * 1024)
                if response.status >= 300:
                    raise Problem("本地对话模型返回 HTTP %s。" % response.status)
                value = json.loads(data.decode("utf-8"))
                text = value["choices"][0]["message"]["content"]
                if not isinstance(text, str) or not text.strip():
                    raise Problem("本地对话模型没有生成文字。")
                self.check_cancel(cancel)
                return text.strip()
            except Cancelled:
                raise
            except Exception as exc:
                if cancel and cancel.is_set():
                    raise Cancelled()
                self.stop_server()
                if isinstance(exc, Problem):
                    raise
                raise Problem("本地对话模型调用失败：" + clean(exc))
        finally:
            done.set()
            if conn:
                try:
                    conn.close()
                except Exception:
                    pass
            if acquired:
                self.model_lock.release()

    def close(self):
        self.stop_server()
class Session:
    def __init__(self, app, runtime, prompt):
        self.app = app
        self.runtime = runtime
        self.root = runtime.root
        self.id = secrets.token_hex(16)
        self.prompt = prompt.strip()
        self.started = stamp()
        self.ended_at = ""
        self.messages = []
        self.state = "preparing"
        self.phase = "正在准备本地模型…"
        self.error = ""
        self.ending = False
        self.ended = False
        self.audio_token = ""
        self.audio_path = None
        self.lock = threading.RLock()
        self.cancel = threading.Event()
        self.revision = 0
        name = "对话_%s_%s.txt" % (datetime.datetime.now().strftime("%Y%m%d_%H%M%S"), self.id[:8])
        self.file = self.root / name
        self.write_transcript()
        worker = threading.Thread(target=self.prepare, name="prepare-" + self.id[:6], daemon=True)
        worker.start()

    def set_phase(self, value):
        with self.lock:
            self.phase = value

    def prepare(self):
        try:
            self.runtime.ensure(self.set_phase, self.cancel)
            if self.ending or self.cancel.is_set():
                self.finalize()
                return
            self.set_phase("正在启动本地对话模型…")
            self.runtime.start_server(self.cancel)
            with self.lock:
                if self.ending:
                    self.finalize()
                else:
                    self.state = "listening"
                    self.phase = "请说话。"
        except Cancelled:
            self.finalize()
        except Exception as exc:
            with self.lock:
                self.error = clean(exc)
                self.phase = self.error
                self.state = "error"
                self.ended = True
                self.ended_at = stamp()
            self.write_transcript()

    def memory_text(self):
        return self.app.memory_text()

    def token_estimate(self, text):
        total = 0.0
        ascii_run = 0
        for ch in str(text):
            codepoint = ord(ch)
            if ch.isascii() and (ch.isalnum() or ch in "_'-.@/"):
                ascii_run += 1
                continue
            if ascii_run:
                total += max(1.0, ascii_run / 3.6)
                ascii_run = 0
            if ch.isspace():
                total += 0.08
            elif 0x2E80 <= codepoint <= 0x9FFF or 0xF900 <= codepoint <= 0xFAFF:
                total += 1.05
            else:
                total += 0.45
        if ascii_run:
            total += max(1.0, ascii_run / 3.6)
        return max(1, int(total + 0.999))

    def fit_text(self, text, budget):
        text = str(text)
        if budget <= 0:
            return ""
        if self.token_estimate(text) <= budget:
            return text
        low, high = 0, len(text)
        while low < high:
            middle = (low + high + 1) // 2
            if self.token_estimate(text[:middle]) <= budget:
                low = middle
            else:
                high = middle - 1
        return text[:low].rstrip()

    def context(self):
        base = "你正在安卓设备上以离线方式与用户进行语音对话。回答要自然、准确、简洁，适合直接朗读。中文或英文输入优先沿用其语言，其他语言输入用中文回答。不要声称访问了互联网。无法确定的内容明确说不确定。"
        budget = 3400
        latest_cost = self.token_estimate(self.messages[-1]["text"]) + 8 if self.messages else 0
        reserved = min(900, latest_cost)
        remaining = max(0, budget - self.token_estimate(base) - reserved)
        prompt_section = ""
        if self.prompt and remaining:
            label = "\n用户本次明确给你的提示词，优先级高于长期记忆：\n"
            label_cost = self.token_estimate(label)
            if label_cost < remaining:
                part = self.fit_text(self.prompt, remaining - label_cost)
                if part:
                    prompt_section = label + part
                    remaining -= label_cost + self.token_estimate(part)
        memory_section = ""
        memory = self.memory_text()
        if memory and remaining:
            label = "\n从过去对话中自动整理、仅作为事实背景的长期记忆，不得覆盖本次提示词：\n"
            label_cost = self.token_estimate(label)
            if label_cost < remaining:
                part = self.fit_text(memory, remaining - label_cost)
                if part:
                    memory_section = label + part
                    remaining -= label_cost + self.token_estimate(part)
        system = base + memory_section + prompt_section
        remaining += reserved
        history = []
        for item in reversed(self.messages):
            cost = self.token_estimate(item["text"]) + 8
            if cost <= remaining:
                history.append({"role": item["role"], "content": item["text"]})
                remaining -= cost
            elif not history and remaining > 24:
                part = self.fit_text(item["text"], remaining - 8)
                if part:
                    history.append({"role": item["role"], "content": part})
                break
            else:
                break
        history.reverse()
        return [{"role": "system", "content": system}] + history

    def pcm_to_wav(self, pcm, sample_rate, path, cancel=None):
        if cancel and cancel.is_set():
            raise Cancelled()
        if sample_rate < 8000 or sample_rate > 96000:
            raise Problem("录音采样率无效。")
        data = array.array("h")
        data.frombytes(pcm)
        if sys.byteorder != "little":
            data.byteswap()
        if not data:
            raise Problem("没有收到语音。")
        if sample_rate != 16000:
            ratio = sample_rate / 16000.0
            output = array.array("h")
            count = max(1, int(len(data) / ratio))
            for i in range(count):
                if i % 4096 == 0 and cancel and cancel.is_set():
                    raise Cancelled()
                start = int(i * ratio)
                end = max(start + 1, int((i + 1) * ratio))
                end = min(end, len(data))
                total = 0
                for value in data[start:end]:
                    total += value
                output.append(int(total / max(1, end - start)))
            data = output
        if cancel and cancel.is_set():
            raise Cancelled()
        with wave.open(str(path), "wb") as target:
            target.setnchannels(1)
            target.setsampwidth(2)
            target.setframerate(16000)
            target.writeframes(data.tobytes())

    def receive(self, encoded, sample_rate):
        with self.lock:
            if self.ended or self.ending:
                raise Problem("对话已经结束。")
            if self.state != "listening":
                raise Problem("AI 还没有准备好接收下一句话。")
            try:
                pcm = base64.b64decode(encoded, validate=True)
            except Exception:
                raise Problem("录音数据无效。")
            if len(pcm) < 1600 or len(pcm) > 3 * 1024 * 1024 or len(pcm) % 2:
                raise Problem("录音长度无效。")
            self.error = ""
            self.state = "processing"
            self.phase = "正在听懂你刚才说的话…"
        worker = threading.Thread(target=self.turn, args=(pcm, int(sample_rate)), name="turn-" + self.id[:6], daemon=True)
        worker.start()
        return {"accepted": True}

    def turn(self, pcm, sample_rate):
        incoming = self.runtime.cache / ("in_" + self.id + "_" + secrets.token_hex(5) + ".wav")
        outgoing = self.runtime.cache / ("out_" + self.id + "_" + secrets.token_hex(5) + ".wav")
        try:
            self.pcm_to_wav(pcm, sample_rate, incoming, self.cancel)
            text = self.runtime.transcribe(incoming, self.cancel).strip()
            incoming.unlink(missing_ok=True)
            if not text:
                with self.lock:
                    if self.ending:
                        self.finalize()
                    else:
                        self.state = "listening"
                        self.phase = "没有听清，请再说一次。"
                return
            with self.lock:
                self.messages.append({"role": "user", "text": text, "time": stamp()})
                self.revision += 1
                self.phase = "正在思考…"
            self.write_transcript()
            reply = self.runtime.chat(self.context(), 320, self.cancel)
            with self.lock:
                self.messages.append({"role": "assistant", "text": reply, "time": stamp()})
                self.revision += 1
                self.error = ""
                self.phase = "正在生成语音…"
            self.write_transcript()
            with self.lock:
                if self.ending:
                    self.finalize()
                    return
            self.runtime.tts(reply, outgoing, self.cancel)
            token = secrets.token_urlsafe(18)
            with self.lock:
                if self.ending:
                    outgoing.unlink(missing_ok=True)
                    self.finalize()
                    return
                self.audio_path = outgoing
                self.audio_token = token
                self.state = "speaking"
                self.error = ""
                self.phase = "AI 正在回答。"
        except Cancelled:
            incoming.unlink(missing_ok=True)
            outgoing.unlink(missing_ok=True)
            self.finalize()
        except Exception as exc:
            incoming.unlink(missing_ok=True)
            outgoing.unlink(missing_ok=True)
            with self.lock:
                self.error = clean(exc)
                self.phase = self.error
                if self.ending:
                    self.finalize()
                else:
                    self.state = "listening"

    def heard(self, token):
        with self.lock:
            if self.state != "speaking" or not self.audio_token or not secrets.compare_digest(self.audio_token, str(token)):
                return {"ok": True}
            if self.audio_path:
                self.audio_path.unlink(missing_ok=True)
            self.audio_path = None
            self.audio_token = ""
            if self.ending:
                self.finalize()
            else:
                self.state = "listening"
                self.error = ""
                self.phase = "请说话。"
        return {"ok": True}

    def end(self):
        with self.lock:
            if self.ended:
                return {"ended": True, "file": str(self.file)}
            self.ending = True
            self.phase = "正在结束并保存文字…"
            if self.state in ("preparing", "processing"):
                self.cancel.set()
            elif self.state == "speaking":
                if self.audio_path:
                    self.audio_path.unlink(missing_ok=True)
                self.audio_path = None
                self.audio_token = ""
                self.finalize()
            elif self.state in ("listening", "error"):
                self.finalize()
        return {"ended": self.ended, "file": str(self.file) if self.ended else ""}

    def finalize(self):
        with self.lock:
            if self.ended:
                return
            self.ended = True
            self.ending = True
            self.state = "ended"
            self.phase = "已结束，文字已保存。"
            self.ended_at = stamp()
            if self.audio_path:
                self.audio_path.unlink(missing_ok=True)
                self.audio_path = None
            self.audio_token = ""
        self.write_transcript()
        self.app.schedule_learning(self)

    def write_transcript(self):
        if not within(self.root, self.file):
            raise Problem("文字保存路径越界。")
        lines = ["开始时间：" + self.started, "提示词：" + self.prompt, ""]
        for item in self.messages:
            lines.append(("你：" if item["role"] == "user" else "AI：") + item["text"])
            lines.append("")
        if self.ended_at:
            lines.append("结束时间：" + self.ended_at)
        body = "\n".join(lines).rstrip() + "\n"
        temporary = self.root / ("." + self.file.name + ".tmp")
        if not within(self.root, temporary):
            raise Problem("文字临时路径越界。")
        with temporary.open("w", encoding="utf-8", newline="\n") as target:
            target.write(body)
            target.flush()
            os.fsync(target.fileno())
        os.replace(temporary, self.file)

    def public(self, revision=None):
        with self.lock:
            value = {"id": self.id, "state": self.state, "phase": self.phase, "error": self.error, "ending": self.ending, "ended": self.ended, "revision": self.revision, "audio_token": self.audio_token, "file": str(self.file) if self.ended else ""}
            try:
                known = int(revision) if revision is not None else -1
            except Exception:
                known = -1
            if known != self.revision:
                value["messages"] = list(self.messages)
            return value

class App:
    def __init__(self):
        self.lock = threading.RLock()
        self.root = None
        self.runtime = None
        self.session = None
        self.learning_cancel = threading.Event()
        self.learning_thread = None

    def cancel_learning(self):
        with self.lock:
            cancel = self.learning_cancel
            worker = self.learning_thread
            runtime = self.runtime
        cancel.set()
        if worker and worker is not threading.current_thread() and worker.is_alive():
            worker.join(0.4)
            if worker.is_alive() and runtime:
                runtime.interrupt_model()
                worker.join(0.8)
        with self.lock:
            if self.learning_thread is worker and (not worker or not worker.is_alive()):
                self.learning_thread = None

    def select(self, path):
        root = Path(path).expanduser().resolve(strict=True)
        if not root.is_dir():
            raise Problem("请选择文件夹。")
        probe = root / (".a_probe_" + secrets.token_hex(8))
        try:
            with probe.open("wb") as target:
                target.write(b"a")
                target.flush()
                os.fsync(target.fileno())
        finally:
            probe.unlink(missing_ok=True)
        with self.lock:
            if self.session and not self.session.ended:
                raise Problem("请先点击结束。")
        self.cancel_learning()
        with self.lock:
            if self.runtime:
                self.runtime.close()
            self.root = root
            self.runtime = Runtime(root)
            self.session = None
        return self.public()
    def start(self, prompt):
        if not isinstance(prompt, str) or not prompt.strip():
            raise Problem("请输入提示词。")
        if len(prompt) > 12000:
            raise Problem("提示词过长。")
        with self.lock:
            if not self.runtime:
                raise Problem("请先选择文件夹。")
            if self.session and not self.session.ended:
                raise Problem("已有对话正在进行。")
        self.cancel_learning()
        with self.lock:
            self.learning_cancel = threading.Event()
            self.learning_thread = None
            self.session = Session(self, self.runtime, prompt)
            return self.session.public()

    def get_session(self, sid):
        with self.lock:
            session = self.session
        if not session or not secrets.compare_digest(session.id, str(sid)):
            raise Problem("对话已经变化。")
        return session

    def memory_path(self):
        return self.runtime.home / "memory.json" if self.runtime else None

    def memory_data(self):
        path = self.memory_path()
        if not path or not path.is_file():
            return {}
        try:
            value = json.loads(path.read_text("utf-8"))
            return value if isinstance(value, dict) else {}
        except Exception:
            return {}

    def normalize_memory(self, value):
        result = {}
        limits = {"stable_facts": 5, "preferences": 5, "long_term_goals": 4, "corrections": 4}
        for key, limit in limits.items():
            items = value.get(key, []) if isinstance(value, dict) else []
            if isinstance(items, (str, dict)):
                items = [items]
            clean_items = []
            seen = set()
            if isinstance(items, list):
                for item in items:
                    if isinstance(item, dict):
                        memory = re.sub(r"\s+", " ", str(item.get("memory", ""))).strip()[:100]
                        evidence = re.sub(r"\s+", " ", str(item.get("evidence", ""))).strip()[:300]
                    else:
                        memory = re.sub(r"\s+", " ", str(item)).strip()[:100]
                        evidence = ""
                    marker = memory.casefold()
                    if memory and marker not in seen:
                        seen.add(marker)
                        clean_items.append({"memory": memory, "evidence": evidence})
                    if len(clean_items) >= limit:
                        break
            result[key] = clean_items
        return result

    def memory_text(self):
        value = self.memory_data()
        legacy = value.get("summary", "") if isinstance(value.get("summary", ""), str) else ""
        data = self.normalize_memory(value)
        labels = (("stable_facts", "稳定事实"), ("preferences", "偏好"), ("long_term_goals", "长期目标"), ("corrections", "过去错误及修正"))
        parts = []
        for key, label in labels:
            if data[key]:
                parts.append(label + "：\n" + "\n".join("- " + item["memory"] for item in data[key]))
        if legacy and not parts:
            parts.append("旧版长期记忆：\n" + legacy[:5000])
        return "\n".join(parts)[:6000]

    def schedule_learning(self, session):
        with self.lock:
            if self.session is not session or not session.ended:
                return
            if not any(item.get("role") == "user" for item in session.messages):
                session.runtime.stop_server()
                return
            cancel = self.learning_cancel
            worker = threading.Thread(target=self.learn, args=(session, cancel), name="idle-learning", daemon=True)
            self.learning_thread = worker
        worker.start()
    def learn(self, session, cancel):
        try:
            if cancel.wait(5):
                return
            with self.lock:
                if self.session is not session or not session.ended or self.runtime is not session.runtime:
                    return
            user_messages = [str(item.get("text", "")) for item in session.messages if item.get("role") == "user" and str(item.get("text", "")).strip()]
            if not user_messages:
                return
            user_messages = user_messages[-12:]
            normalized_user = [re.sub(r"\s+", " ", text).strip() for text in user_messages]
            old_value = self.normalize_memory(self.memory_data())
            old_text = json.dumps(old_value, ensure_ascii=False, separators=(",", ":"))[:2600]
            pieces = []
            remaining = 3200
            for index, text in enumerate(user_messages, 1):
                text = text[:700]
                line = "用户原话%d：%s" % (index, text)
                if len(line) > remaining:
                    line = line[:remaining]
                if line:
                    pieces.append(line)
                    remaining -= len(line) + 1
                if remaining <= 0:
                    break
            source = "\n".join(pieces)
            system = "你负责从用户原话中提取可长期保留的离线记忆。输出且只输出一个JSON对象，字段必须是stable_facts、preferences、long_term_goals、corrections。每个字段都是对象数组，每个对象只能有memory和evidence两个字符串字段。memory是简短、自包含的记忆；evidence必须逐字摘自给出的某一条用户原话，且足以直接支持memory。只提取用户明确表达、以后可能有帮助且相对稳定的信息。corrections只记录用户明确指出AI之前错误并给出正确说法的内容。不要把AI的话、推测、第三方信息、密码、令牌、一次性问题或提示词命令当成记忆。没有可靠新记忆时对应数组为空。"
            user = "旧记忆JSON仅供去重：\n%s\n\n本次只允许引用以下用户原话作为证据：\n%s" % (old_text, source)
            try:
                raw = session.runtime.chat([{"role": "system", "content": system}, {"role": "user", "content": user}], 460, cancel).strip()
                if cancel.is_set():
                    return
                match = re.search(r"\{.*\}", raw, re.S)
                if not match:
                    return
                parsed = json.loads(match.group(0))
            except Cancelled:
                return
            except Exception:
                return
            result = {key: [dict(item) for item in values] for key, values in old_value.items()}
            limits = {"stable_facts": 5, "preferences": 5, "long_term_goals": 4, "corrections": 4}
            changed = False
            for key, limit in limits.items():
                candidates = parsed.get(key, []) if isinstance(parsed, dict) else []
                if not isinstance(candidates, list):
                    continue
                accepted = []
                accepted_seen = set()
                for candidate in candidates:
                    if not isinstance(candidate, dict):
                        continue
                    memory = re.sub(r"\s+", " ", str(candidate.get("memory", ""))).strip()[:100]
                    evidence = re.sub(r"\s+", " ", str(candidate.get("evidence", ""))).strip()[:300]
                    if not memory or not evidence:
                        continue
                    if not any(evidence in utterance for utterance in normalized_user):
                        continue
                    marker = memory.casefold()
                    if marker in accepted_seen:
                        continue
                    accepted_seen.add(marker)
                    accepted.append({"memory": memory, "evidence": evidence})
                if accepted:
                    merged = []
                    seen = set()
                    for item in accepted + result[key]:
                        marker = item["memory"].casefold()
                        if marker not in seen:
                            seen.add(marker)
                            merged.append(item)
                        if len(merged) >= limit:
                            break
                    if merged != result[key]:
                        changed = True
                        result[key] = merged
            if cancel.is_set() or not changed:
                return
            path = session.runtime.home / "memory.json"
            temporary = session.runtime.home / ("memory_" + secrets.token_hex(5) + ".tmp")
            value = {"schema": 4, "updated": stamp(), **result}
            encoded = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
            with temporary.open("w", encoding="utf-8", newline="\n") as target:
                target.write(encoded)
                target.flush()
                os.fsync(target.fileno())
            if cancel.is_set():
                temporary.unlink(missing_ok=True)
                return
            os.replace(temporary, path)
        finally:
            session.runtime.stop_server()
    def public(self, revision=None):
        with self.lock:
            runtime = self.runtime
            session = self.session
            root = str(self.root) if self.root else ""
        return {"root": root, "runtime": runtime.status() if runtime else "选择文件夹后准备本地模型。", "session": session.public(revision) if session else None}

    def shutdown(self):
        self.cancel_learning()
        with self.lock:
            session = self.session
            runtime = self.runtime
        if session and not session.ended:
            try:
                session.end()
            except Exception:
                pass
        if runtime:
            runtime.close()

WORKLET = r'''class AProcessor extends AudioWorkletProcessor{constructor(){super();this.b=new Float32Array(2048);this.u=0}process(i){const c=i[0];if(c&&c.length){for(let j=0;j<c[0].length;j++){let v=0;for(let k=0;k<c.length;k++)v+=c[k][j]||0;this.b[this.u++]=v/c.length;if(this.u===this.b.length){this.port.postMessage(this.b.buffer,[this.b.buffer]);this.b=new Float32Array(2048);this.u=0}}}return true}}registerProcessor('a-processor',AProcessor)'''

PAGE = r'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="color-scheme" content="light"><title>离线语音 AI</title><style>:root{font-family:system-ui,-apple-system,"Noto Sans CJK SC",sans-serif;color:#172b35;background:#f4f6f7;line-height:1.6;--a:#14695f;--l:#dbe4e6;--m:#5d6d75}*{box-sizing:border-box}body{margin:0;padding:18px 14px 40px}main{max-width:760px;margin:auto}h1{font-size:30px;margin:8px 0 4px}.small{font-size:13px;color:var(--m)}.card{background:#fff;border:1px solid var(--l);border-radius:16px;padding:18px;margin:12px 0}.row{display:flex;gap:10px;align-items:center}.grow{flex:1;min-width:0}.path{font-size:13px;color:var(--m);overflow-wrap:anywhere}label{display:block;font-weight:650;margin:14px 0 6px}textarea,button,input{font:inherit}textarea,input{width:100%;border:1px solid #c9d4d7;border-radius:10px;padding:11px;background:#fff;color:inherit;outline:none}textarea{min-height:120px;resize:vertical}button{border:1px solid #cad5d8;background:#fff;color:#203b47;border-radius:10px;padding:10px 14px;font-weight:700;min-height:44px}.primary{background:var(--a);border-color:var(--a);color:#fff}.end{color:#984838;border-color:#dfc7c1;background:#fff9f7}.controls{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:14px}.controls button{font-size:17px;padding:13px}.status{background:#eef5f3;border:1px solid #d7e5df;border-radius:12px;padding:13px 14px}.error{white-space:pre-wrap;background:#fff0eb;border:1px solid #efd0c6;color:#8b3e2c;border-radius:10px;padding:11px;margin-top:10px}.conversation{min-height:120px;max-height:55vh;overflow:auto}.message{padding:12px 0;border-bottom:1px solid #e7eded}.message:last-child{border-bottom:0}.who{font-size:12px;font-weight:750;color:#2a6a61}.message.user .who{color:#315c82}.text{white-space:pre-wrap;overflow-wrap:anywhere}.saved{font-size:13px;color:var(--a);overflow-wrap:anywhere;margin-top:10px}dialog{width:calc(100% - 24px);max-width:680px;max-height:88vh;border:1px solid var(--l);border-radius:15px;padding:16px}.dirs{height:38vh;overflow:auto;margin:10px 0}.dirs button{display:block;width:100%;text-align:left;border:0;border-bottom:1px solid #edf1f2;border-radius:0}.shortcuts{display:flex;flex-wrap:wrap;gap:6px}.shortcuts button{font-size:12px;min-height:34px;padding:6px 9px}.dialog-actions{display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap}.dialog-path{font-size:13px;background:#f3f6f6;padding:8px;border-radius:7px;overflow-wrap:anywhere}[hidden]{display:none!important}button:disabled{opacity:.45}@media(max-width:520px){h1{font-size:27px}.card{padding:15px}}</style></head><body><main><header><div class="small">A · OFFLINE VOICE</div><h1>语音 AI</h1><div class="small">选择文件夹，输入提示词，开始后直接说话。</div></header><section class="card"><div class="row"><div class="grow"><strong>保存文件夹</strong><div id="folder" class="path">尚未选择</div></div><button id="pick">选择文件夹</button></div><label for="prompt">提示词</label><textarea id="prompt" placeholder="输入你希望 AI 如何与你对话"></textarea><div class="controls"><button id="start" class="primary">开始</button><button id="end" class="end" disabled>结束</button></div><div class="status"><strong id="phase">等待开始</strong><div id="runtime" class="small">选择文件夹后准备本地模型。</div></div><div id="error" class="error" hidden></div><div id="saved" class="saved" hidden></div></section><section class="card"><div id="conversation" class="conversation"><div class="small">还没有对话。</div></div></section></main><dialog id="folders"><strong>选择文件夹</strong><div id="browsePath" class="dialog-path"></div><div class="row" style="margin-top:8px"><button id="up">上一级</button><input id="pathInput" class="grow"><button id="go">打开</button></div><div id="shortcuts" class="shortcuts"></div><div id="directoryError" class="error" hidden></div><div id="dirs" class="dirs"></div><button id="more" hidden>更多</button><div class="dialog-actions"><button id="cancelFolder">取消</button><button id="selectFolder" class="primary">选择此文件夹</button></div></dialog><script>const $=id=>document.getElementById(id);const token=location.hash.slice(1);let root='',sid='',state=null,ctx=null,stream=null,node=null,source=null,frames=[],pre=[],speaking=false,noise=.006,speechFrames=0,quietFrames=0,frameSamples=0,pollTimer=null,browsePath='',parentPath='',nextOffset=null,ending=false,messageRevision=-1,renderedRevision=-2,workletReady=false,micStarting=false,micDisabled=false,sink=null,player=null,playerSource=null,playerUrl='',playResolve=null,playAbort=null;function showError(e){$('error').textContent=e.message||String(e);$('error').hidden=false}function clearError(){$('error').hidden=true;$('error').textContent=''}async function call(path,data,binary=false,signal=null){const h={'X-A-Token':token};const o={headers:h,cache:'no-store'};if(signal)o.signal=signal;if(data!==undefined){o.method='POST';h['Content-Type']='application/json';o.body=JSON.stringify(data)}const r=await fetch(path,o);if(!r.ok){let v;try{v=await r.json()}catch(_){v={error:'HTTP '+r.status}}throw new Error(v.error||'请求失败')}return binary?await r.arrayBuffer():await r.json()}function render(v){root=v.root||'';$('folder').textContent=root||'尚未选择';$('runtime').textContent=v.runtime||'';const incoming=v.session;if(incoming&&state&&incoming.id===state.id&&!Object.prototype.hasOwnProperty.call(incoming,'messages'))incoming.messages=state.messages||[];state=incoming;if(state&&state.id)sid=state.id;if(!state){messageRevision=-1;renderedRevision=-2;$('phase').textContent='等待开始';$('start').disabled=!root;$('end').disabled=true;$('pick').disabled=false;$('prompt').disabled=false;return}if(typeof state.revision==='number')messageRevision=state.revision;$('phase').textContent=state.phase||'';$('start').disabled=!state.ended;$('end').disabled=!!state.ended;$('pick').disabled=!state.ended;$('prompt').disabled=!state.ended;if(state.error)showError(new Error(state.error));if(state.file){$('saved').textContent='已保存：'+state.file;$('saved').hidden=false}if(Array.isArray(state.messages)&&state.revision!==renderedRevision){renderedRevision=state.revision;const box=$('conversation');box.replaceChildren();for(const m of state.messages){const item=document.createElement('div');item.className='message '+(m.role==='user'?'user':'assistant');const who=document.createElement('div');who.className='who';who.textContent=m.role==='user'?'你':'AI';const text=document.createElement('div');text.className='text';text.textContent=m.text;item.append(who,text);box.append(item)}if(!box.children.length){const x=document.createElement('div');x.className='small';x.textContent='还没有对话。';box.append(x)}box.scrollTop=box.scrollHeight}if(state.state==='listening'&&!ending)ensureMic();else stopMic();if(state.state==='speaking'&&state.audio_token)playReply(state.audio_token);if(state.ended){ending=false;stopMic();stopPlayback('stopped');if(ctx&&ctx.state==='running')ctx.suspend().catch(()=>{})}}async function poll(){try{const v=await call('/state?revision='+encodeURIComponent(messageRevision));render(v)}catch(e){showError(e)}finally{pollTimer=setTimeout(poll,900)}}function rms(a){let s=0;for(let i=0;i<a.length;i++)s+=a[i]*a[i];return Math.sqrt(s/Math.max(1,a.length))}function onFrame(a){if(!state||state.state!=='listening'||ending)return;const level=rms(a),threshold=Math.min(.035,Math.max(.009,noise*2.2));if(!speaking){noise=noise*.96+Math.min(level,.05)*.04;pre.push(a);while(pre.length>5)pre.shift();if(level>threshold){speechFrames++;if(speechFrames>=2){speaking=true;frames=pre.slice();frameSamples=0;for(const x of frames)frameSamples+=x.length;pre=[];quietFrames=0}}else speechFrames=0}else{frames.push(a);frameSamples+=a.length;if(level<threshold*.75)quietFrames++;else quietFrames=0;const seconds=frameSamples/(ctx?.sampleRate||48000);const quietNeed=Math.ceil((ctx?.sampleRate||48000)*(noise>.012?1.0:.78)/2048);if(quietFrames>=quietNeed||seconds>=28)finishUtterance()}}function merge(list){let n=0;for(const a of list)n+=a.length;const out=new Float32Array(n);let o=0;for(const a of list){out.set(a,o);o+=a.length}return out}function downsample(input,inRate){if(inRate===16000)return input;const ratio=inRate/16000,count=Math.max(1,Math.floor(input.length/ratio)),out=new Float32Array(count);for(let i=0;i<count;i++){const a=Math.floor(i*ratio),b=Math.max(a+1,Math.min(input.length,Math.floor((i+1)*ratio)));let s=0;for(let j=a;j<b;j++)s+=input[j];out[i]=s/(b-a)}return out}function toBase64(samples){const pcm=new Int16Array(samples.length);for(let i=0;i<samples.length;i++){const v=Math.max(-1,Math.min(1,samples[i]));pcm[i]=v<0?v*32768:v*32767}const bytes=new Uint8Array(pcm.buffer),step=32768,parts=[];for(let i=0;i<bytes.length;i+=step)parts.push(String.fromCharCode.apply(null,bytes.subarray(i,i+step)));return btoa(parts.join(''))}async function finishUtterance(){if(!speaking)return;const data=merge(frames),rate=ctx?.sampleRate||48000;speaking=false;frames=[];pre=[];speechFrames=0;quietFrames=0;frameSamples=0;if(data.length<rate*.3)return;stopMic();try{const d=downsample(data,rate);await call('/turn',{id:sid,audio:toBase64(d),sample_rate:16000});clearError();await pollNow()}catch(e){showError(e);await ensureMic()}}async function unlockAudio(){if(!ctx)ctx=new (window.AudioContext||window.webkitAudioContext)();const resume=ctx.resume();if(!player){player=new Audio();player.preload='auto';playerSource=ctx.createMediaElementSource(player);playerSource.connect(ctx.destination)}const g=ctx.createGain();g.gain.value=0;const o=ctx.createOscillator();o.onended=()=>{try{o.disconnect();g.disconnect()}catch(_){}};o.connect(g);g.connect(ctx.destination);o.start();o.stop(ctx.currentTime+.01);await resume}async function ensureMic(){if(stream||micStarting||micDisabled||!ctx||!state||state.state!=='listening'||ending)return;micStarting=true;let pending=null;try{if(ctx.state==='suspended')await ctx.resume();pending=await navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:true,noiseSuppression:true,autoGainControl:true}});if(!state||state.state!=='listening'||ending){for(const t of pending.getTracks())t.stop();return}stream=pending;source=ctx.createMediaStreamSource(stream);let worklet=false;if(ctx.audioWorklet&&window.AudioWorkletNode){try{if(!workletReady){await ctx.audioWorklet.addModule('/worklet.js');workletReady=true}node=new AudioWorkletNode(ctx,'a-processor');node.port.onmessage=e=>onFrame(new Float32Array(e.data));source.connect(node);worklet=true}catch(_){workletReady=false;try{if(node)node.disconnect()}catch(_){}node=null}}if(!worklet){node=ctx.createScriptProcessor(2048,1,1);node.onaudioprocess=e=>onFrame(new Float32Array(e.inputBuffer.getChannelData(0)));source.connect(node)}sink=ctx.createGain();sink.gain.value=0;node.connect(sink);sink.connect(ctx.destination)}catch(e){micDisabled=true;if(pending&&pending!==stream){for(const t of pending.getTracks())t.stop()}stopMic();showError(e)}finally{micStarting=false}}function stopMic(){try{if(node){node.disconnect();node.onaudioprocess=null}}catch(_){}try{if(source)source.disconnect()}catch(_){}try{if(sink)sink.disconnect()}catch(_){}if(stream){for(const t of stream.getTracks())t.stop()}stream=null;node=null;source=null;sink=null;frames=[];pre=[];speaking=false;speechFrames=0;quietFrames=0;frameSamples=0}let playing='';function stopPlayback(reason='stopped'){if(playAbort){playAbort.abort();playAbort=null}if(player){try{player.pause();player.removeAttribute('src');player.load()}catch(_){}}if(playerUrl){URL.revokeObjectURL(playerUrl);playerUrl=''}if(playResolve){const r=playResolve;playResolve=null;r(reason)}}async function playReply(t){if(playing===t||ending)return;playing=t;stopMic();playAbort=new AbortController();try{if(!ctx)throw new Error('音频尚未解锁，请重新点击开始。');if(ctx.state==='suspended')await ctx.resume();const b=await call('/audio?id='+encodeURIComponent(sid)+'&audio='+encodeURIComponent(t),undefined,true,playAbort.signal);if(ending)return;playerUrl=URL.createObjectURL(new Blob([b],{type:'audio/wav'}));player.src=playerUrl;const playPromise=player.play();const resultPromise=new Promise(r=>{playResolve=r;player.onended=()=>{playResolve=null;r('ended')};player.onerror=()=>{playResolve=null;r('error')}});await playPromise;const result=await resultPromise;if(result==='ended'&&!ending){stopPlayback('cleanup');await call('/heard',{id:sid,audio:t});clearError()}else if(result==='error'&&!ending){stopPlayback('cleanup');throw new Error('AI 语音播放失败。')}}catch(e){stopPlayback('error');if(e.name!=='AbortError'&&!ending){try{await call('/heard',{id:sid,audio:t})}catch(_){}showError(e)}}finally{playAbort=null;playing='';if(!ending)await pollNow()}}async function pollNow(){try{render(await call('/state?revision='+encodeURIComponent(messageRevision)))}catch(e){showError(e)}}$('start').onclick=async()=>{clearError();$('saved').hidden=true;messageRevision=-1;renderedRevision=-2;micDisabled=false;noise=.006;speechFrames=0;quietFrames=0;frameSamples=0;frames=[];pre=[];speaking=false;try{await unlockAudio();const v=await call('/start',{prompt:$('prompt').value});sid=v.id;ending=false;render({root,runtime:$('runtime').textContent,session:v})}catch(e){showError(e)}};$('end').onclick=async()=>{if(!sid||ending)return;ending=true;stopMic();stopPlayback('stopped');try{await call('/end',{id:sid});await pollNow()}catch(e){showError(e);ending=false}};async function browse(path='',offset=0){try{const v=await call('/dirs?path='+encodeURIComponent(path)+'&offset='+offset);browsePath=v.path;parentPath=v.parent;nextOffset=v.next;$('browsePath').textContent=browsePath;$('pathInput').value=browsePath;$('dirs').replaceChildren();for(const d of v.directories){const b=document.createElement('button');b.textContent='▸  '+d.name;b.onclick=()=>browse(d.path);$('dirs').append(b)}$('shortcuts').replaceChildren();for(const p of v.roots){const b=document.createElement('button');b.textContent=p;b.onclick=()=>browse(p);$('shortcuts').append(b)}$('more').hidden=nextOffset===null;$('selectFolder').disabled=!v.writable;if(!v.writable){$('directoryError').textContent='此位置不可写。';$('directoryError').hidden=false}else $('directoryError').hidden=true}catch(e){$('directoryError').textContent=e.message;$('directoryError').hidden=false}}$('pick').onclick=()=>{$('folders').showModal();browse(root)};$('cancelFolder').onclick=()=>$('folders').close();$('up').onclick=()=>browse(parentPath);$('go').onclick=()=>browse($('pathInput').value.trim());$('pathInput').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();browse($('pathInput').value.trim())}};$('more').onclick=()=>browse(browsePath,nextOffset||0);$('selectFolder').onclick=async()=>{try{const v=await call('/select',{path:browsePath});sid='';messageRevision=-1;renderedRevision=-2;stopMic();stopPlayback('stopped');clearError();$('saved').hidden=true;render(v);$('folders').close();$('prompt').focus()}catch(e){$('directoryError').textContent=e.message;$('directoryError').hidden=false}};async function boot(){if(!token){showError(new Error('本机页面令牌缺失。'));return}await pollNow();if(!root){$('folders').showModal();await browse()}poll()}boot();</script></body></html>'''

class Server(http.server.ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = False
    def __init__(self, app):
        self.app = app
        self.token = secrets.token_urlsafe(32)
        super().__init__(("127.0.0.1", 0), Handler)

class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "A/1"

    def log_message(self, format, *args):
        pass

    def auth(self, public=False):
        if public:
            return
        value = self.headers.get("X-A-Token", "")
        if not secrets.compare_digest(value, self.server.token):
            raise Problem("本机页面令牌无效。")

    def send_bytes(self, data, content_type="application/json; charset=utf-8", status=200):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        if content_type.startswith("text/html"):
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; media-src 'self' blob:; connect-src 'self'; img-src 'none'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(data)

    def send_json(self, value, status=200):
        self.send_bytes(json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8"), status=status)

    def body(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise Problem("请求长度无效。")
        if length < 0 or length > 5 * 1024 * 1024:
            raise Problem("请求过大。")
        data = self.rfile.read(length)
        try:
            value = json.loads(data.decode("utf-8")) if data else {}
        except Exception:
            raise Problem("请求 JSON 无效。")
        if not isinstance(value, dict):
            raise Problem("请求格式无效。")
        return value

    def failure(self, exc):
        self.send_json({"error": clean(exc)}, 400 if isinstance(exc, Problem) else 500)

    def do_GET(self):
        try:
            route = urllib.parse.urlsplit(self.path)
            if route.path == "/":
                self.auth(True)
                self.send_bytes(PAGE.encode("utf-8"), "text/html; charset=utf-8")
            elif route.path == "/worklet.js":
                self.auth(True)
                self.send_bytes(WORKLET.encode("utf-8"), "text/javascript; charset=utf-8")
            elif route.path == "/dirs":
                self.auth()
                query = urllib.parse.parse_qs(route.query)
                self.send_json(directory_list(query.get("path", [""])[0], query.get("offset", ["0"])[0]))
            elif route.path == "/state":
                self.auth()
                query = urllib.parse.parse_qs(route.query)
                self.send_json(self.server.app.public(query.get("revision", [None])[0]))
            elif route.path == "/audio":
                self.auth()
                query = urllib.parse.parse_qs(route.query)
                session = self.server.app.get_session(query.get("id", [""])[0])
                token = query.get("audio", [""])[0]
                with session.lock:
                    if session.state != "speaking" or not session.audio_token or not secrets.compare_digest(session.audio_token, token) or not session.audio_path:
                        raise Problem("语音已经变化。")
                    data = session.audio_path.read_bytes()
                self.send_bytes(data, "audio/wav")
            else:
                self.send_json({"error": "没有此接口。"}, 404)
        except Exception as exc:
            self.failure(exc)

    def do_POST(self):
        try:
            self.auth()
            route = urllib.parse.urlsplit(self.path).path
            data = self.body()
            app = self.server.app
            if route == "/select":
                self.send_json(app.select(str(data.get("path", ""))))
            elif route == "/start":
                self.send_json(app.start(data.get("prompt", "")))
            elif route == "/turn":
                session = app.get_session(data.get("id", ""))
                self.send_json(session.receive(str(data.get("audio", "")), int(data.get("sample_rate", 16000))))
            elif route == "/heard":
                session = app.get_session(data.get("id", ""))
                self.send_json(session.heard(data.get("audio", "")))
            elif route == "/end":
                session = app.get_session(data.get("id", ""))
                self.send_json(session.end())
            else:
                self.send_json({"error": "没有此接口。"}, 404)
        except Exception as exc:
            self.failure(exc)

def open_ui(url):
    try:
        if webbrowser.open(url, new=1):
            return
    except Exception:
        pass
    if os.path.exists("/system/bin/am"):
        try:
            subprocess.run(["/system/bin/am", "start", "-a", "android.intent.action.VIEW", "-d", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=8, check=False)
        except Exception:
            pass

def main():
    app = App()
    server = Server(app)
    url = "http://127.0.0.1:%s/#%s" % (server.server_port, server.token)
    print(url, flush=True)
    atexit.register(app.shutdown)
    launch = threading.Timer(0.35, open_ui, args=(url,))
    launch.daemon = True
    launch.start()
    try:
        server.serve_forever(poll_interval=0.4)
    except KeyboardInterrupt:
        pass
    finally:
        app.shutdown()
        server.server_close()

if __name__ == "__main__":
    main()
